from setuptools import setup


setup(name='hourcounter',
      version='0.0.8',
      description='Count the number of items in the time interval',
      long_description='Count the number of items in the time interval',
      long_description_content='Count the number of items in the time interval',
      packages=['hourcounter'],
      author='Davuluri Hemanth Chowdary',
      author_email='hemanthdavuluri98@gmail.com',
      zip_safe=False)